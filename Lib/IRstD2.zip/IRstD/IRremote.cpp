
#include <avr/interrupt.h>

// Defining IR_GLOBAL here allows us to declare the instantiation of global variables
#define IR_GLOBAL
#	include "IRstD.h"
#	include "IRremoteInt.h"
#undef IR_GLOBAL


int  MATCHstd (int measured,  int desired)
{
 	DBG_PRINT("Testing: ");
 	DBG_PRINT(TICKS_LOW(desired), DEC);
 	DBG_PRINT(" <= ");
 	DBG_PRINT(measured, DEC);
 	DBG_PRINT(" <= ");
 	DBG_PRINTLN(TICKS_HIGH(desired), DEC);

 	return ((measured >= TICKS_LOW(desired)) && (measured <= TICKS_HIGH(desired)));
}

//+========================================================
// Due to sensor lag, when received, Marks tend to be 100us too long
//
int  MATCH_MARKstd (int measured_ticks,  int desired_us)
{
	DBG_PRINT("Testing mark ");
	DBG_PRINT(measured_ticks * USECPERTICK, DEC);
	DBG_PRINT(" vs ");
	DBG_PRINT(desired_us, DEC);
	DBG_PRINT(": ");
	DBG_PRINT(TICKS_LOW(desired_us + MARK_EXCESS), DEC);
	DBG_PRINT(" <= ");
	DBG_PRINT(measured_ticks, DEC);
	DBG_PRINT(" <= ");
	DBG_PRINTLN(TICKS_HIGH(desired_us + MARK_EXCESS), DEC);

	return ((measured_ticks >= TICKS_LOW (desired_us + MARK_EXCESS))
	     && (measured_ticks <= TICKS_HIGH(desired_us + MARK_EXCESS)));
}

//+========================================================
// Due to sensor lag, when received, Spaces tend to be 100us too short
//
int  MATCH_SPACEstd (int measured_ticks,  int desired_us)
{
	DBG_PRINT("Testing space ");
	DBG_PRINT(measured_ticks * USECPERTICK, DEC);
	DBG_PRINT(" vs ");
	DBG_PRINT(desired_us, DEC);
	DBG_PRINT(": ");
	DBG_PRINT(TICKS_LOW(desired_us - MARK_EXCESS), DEC);
	DBG_PRINT(" <= ");
	DBG_PRINT(measured_ticks, DEC);
	DBG_PRINT(" <= ");
	DBG_PRINTLN(TICKS_HIGH(desired_us - MARK_EXCESS), DEC);

	return ((measured_ticks >= TICKS_LOW (desired_us - MARK_EXCESS))
	     && (measured_ticks <= TICKS_HIGH(desired_us - MARK_EXCESS)));
}


ISR (TIMER_INTR_NAME)
{
	TIMER_RESET;

	// Read if IR Receiver -> SPACE [xmt LED off] or a MARK [xmt LED on]
	// digitalRead() is very slow. Optimisation is possible, but makes the code unportable
	uint8_t  irdata = (uint8_t)digitalRead(irparamsstd.recvpin);

	irparamsstd.timer++;  // One more 50uS tick
	if (irparamsstd.rawlenstd >= RAWBUFstd)  irparamsstd.rcvstate = STATE_OVERFLOW ;  // Buffer overflow

	switch(irparamsstd.rcvstate) {
		//......................................................................
		case STATE_IDLE: // In the middle of a gap
			if (irdata == MARK) {
				if (irparamsstd.timer < GAP_TICKS)  {  // Not big enough to be a gap.
					irparamsstd.timer = 0;

				} else {
					// Gap just ended; Record duration; Start recording transmission
					irparamsstd.overflowstd                  = false;
					irparamsstd.rawlenstd                    = 0;
					irparamsstd.rawbufstd[irparamsstd.rawlenstd++] = irparamsstd.timer;
					irparamsstd.timer                     = 0;
					irparamsstd.rcvstate                  = STATE_MARK;
				}
			}
			break;
		//......................................................................
		case STATE_MARK:  // Timing Mark
			if (irdata == SPACE) {   // Mark ended; Record time
				irparamsstd.rawbufstd[irparamsstd.rawlenstd++] = irparamsstd.timer;
				irparamsstd.timer                     = 0;
				irparamsstd.rcvstate                  = STATE_SPACE;
			}
			break;
		//......................................................................
		case STATE_SPACE:  // Timing Space
			if (irdata == MARK) {  // Space just ended; Record time
				irparamsstd.rawbufstd[irparamsstd.rawlenstd++] = irparamsstd.timer;
				irparamsstd.timer                     = 0;
				irparamsstd.rcvstate                  = STATE_MARK;

			} else if (irparamsstd.timer > GAP_TICKS) {  // Space
					// A long Space, indicates gap between codes
					// Flag the current code as ready for processing
					// Switch to STOP
					// Don't reset timer; keep counting Space width
					irparamsstd.rcvstate = STATE_STOP;
			}
			break;
		//......................................................................
		case STATE_STOP:  // Waiting; Measuring Gap
		 	if (irdata == MARK)  irparamsstd.timer = 0 ;  // Reset gap timer
		 	break;
		//......................................................................
		case STATE_OVERFLOW:  // Flag up a read overflow; Stop the State Machine
			irparamsstd.overflowstd = true;
			irparamsstd.rcvstate = STATE_STOP;
		 	break;
	}

	// If requested, flash LED while receiving IR data
	if (irparamsstd.blinkflag) {
		if (irdata == MARK)
			if (irparamsstd.blinkpin) digitalWrite(irparamsstd.blinkpin, HIGH); // Turn user defined pin LED on
				else BLINKLED_ON() ;   // if no user defined LED pin, turn default LED pin for the hardware on
		else if (irparamsstd.blinkpin) digitalWrite(irparamsstd.blinkpin, LOW); // Turn user defined pin LED on
				else BLINKLED_OFF() ;   // if no user defined LED pin, turn default LED pin for the hardware on
	}
}
