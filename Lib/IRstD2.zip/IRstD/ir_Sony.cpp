#include "IRstD.h"
#include "IRremoteInt.h"

//==============================================================================
//                           SSSS   OOO   N   N  Y   Y
//                          S      O   O  NN  N   Y Y
//                           SSS   O   O  N N N    Y
//                              S  O   O  N  NN    Y
//                          SSSS    OOO   N   N    Y
//==============================================================================

#define SONY_BITS                   12
#define SONY_HDR_MARK             2400
#define SONY_HDR_SPACE             600
#define SONY_ONE_MARK             1200
#define SONY_ZERO_MARK             600
#define SONY_RPT_LENGTH          45000
#define SONY_DOUBLE_SPACE_USECS    500  // usually ssee 713 - not using ticks as get number wrapround

//+=============================================================================
#if SEND_SONY
void  IRsendstd::sendSonystd (unsigned long data,  int nbits)
{
	// Set IR carrier frequency
	enableIROutstd(40);

	// Header
	mark(SONY_HDR_MARK);
	space(SONY_HDR_SPACE);

	// Data
	for (unsigned long  mask = 1UL << (nbits - 1);  mask;  mask >>= 1) {
		if (data & mask) {
			mark(SONY_ONE_MARK);
			space(SONY_HDR_SPACE);
		} else {
			mark(SONY_ZERO_MARK);
			space(SONY_HDR_SPACE);
    	}
  	}

	// We will have ended with LED off
}
#endif

//+=============================================================================
#if DECODE_SONY
bool  IRrecvstd::decodeSonystd (decode_resultsstd *resultstd)
{
	long  data   = 0;
	int   offset = 0;  // Dont skip first space, check its size

	if (irparamsstd.rawlenstd < (2 * SONY_BITS) + 2)  return false ;

	// Some Sony's deliver repeats fast after first
	// unfortunately can't spot difference from of repeat from two fast clicks
	if (resultstd->rawbufstd[offset] < SONY_DOUBLE_SPACE_USECS) {
		// Serial.print("IR Gap found: ");
		resultstd->bitsstd = 0;
		resultstd->valuestd = REPEATstd;

#	ifdef DECODE_SANYO
		resultstd->decode_typestd = SANYOstd;
#	else
		resultstd->decode_typestd = UNKNOWNstd;
#	endif

	    return true;
	}
	offset++;

	// Initial mark
	if (!MATCH_MARKstd(resultstd->rawbufstd[offset++], SONY_HDR_MARK))  return false ;

	while (offset + 1 < irparamsstd.rawlenstd) {
		if (!MATCH_SPACEstd(resultstd->rawbufstd[offset++], SONY_HDR_SPACE))  break ;

		if      (MATCH_MARKstd(resultstd->rawbufstd[offset], SONY_ONE_MARK))   data = (data << 1) | 1 ;
		else if (MATCH_MARKstd(resultstd->rawbufstd[offset], SONY_ZERO_MARK))  data = (data << 1) | 0 ;
		else                                                           return false ;
		offset++;
	}

	// Success
	resultstd->bitsstd = (offset - 1) / 2;
	if (resultstd->bitsstd < 12) {
		resultstd->bitsstd = 0;
		return false;
	}
	resultstd->valuestd       = data;
	resultstd->decode_typestd = SONYstd;
	return true;
}
#endif

