
//******************************************************************************
// IRremote
// Version 2.0.1 June, 2015
// Copyright 2009 Ken Shirriff
// For details, see http://arcfn.com/2009/08/multi-protocol-infrared-remote-library.html
// Edited by Mitra to add new controller SANYO
//
// Interrupt code based on NECIRrcv by Joe Knapp
// http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1210243556
// Also influenced by http://zovirl.com/2008/11/12/building-a-universal-remote-with-an-arduino/
//
// JVC and Panasonic protocol added by Kristian Lauszus (Thanks to zenwheel and other people at the original blog post)
// LG added by Darryl Smith (based on the JVC protocol)
// Whynter A/C ARC-110WD added by Francesco Meschia
//******************************************************************************

#ifndef IRstD_h
#define IRstD_h

//------------------------------------------------------------------------------
// The ISR header contains several useful macros the user may wish to use
//
#include "IRremoteInt.h"

//------------------------------------------------------------------------------
// Supported IR protocols
// Each protocol you include costs memory and, during decode, costs time
// Disable (set to 0) all the protocols you do not need/want!
//
#define DECODE_RC5           1
#define SEND_RC5             1

#define DECODE_RC6           1
#define SEND_RC6             1

#define DECODE_NEC           1
#define SEND_NEC             1

#define DECODE_SONY          1
#define SEND_SONY            1

#define DECODE_PANASONIC     1
#define SEND_PANASONIC       1

#define DECODE_JVC           1
#define SEND_JVC             1

#define DECODE_SAMSUNG       1
#define SEND_SAMSUNG         1

#define DECODE_WHYNTER       1
#define SEND_WHYNTER         1

#define DECODE_AIWA_RC_T501  1
#define SEND_AIWA_RC_T501    1

#define DECODE_LG            1
#define SEND_LG              1 

#define DECODE_SANYO         1
#define SEND_SANYO           0 // NOT WRITTEN

#define DECODE_MITSUBISHI    1
#define SEND_MITSUBISHI      0 // NOT WRITTEN

#define DECODE_DISH          0 // NOT WRITTEN
#define SEND_DISH            1

#define DECODE_SHARP         0 // NOT WRITTEN
#define SEND_SHARP           1

#define DECODE_DENON         1
#define SEND_DENON           1

#define DECODE_PRONTO        0 // This function doe not logically make sense
#define SEND_PRONTO          1

//------------------------------------------------------------------------------
// When sending a Pronto code we request to send either the "once" code
//                                                   or the "repeat" code
// If the code requested does not exist we can request to fallback on the
// other code (the one we did not explicitly request)
//
// I would suggest that "fallback" will be the standard calling method
// The last paragraph on this page discusses the rationale of this idea:
//   http://www.remotecentral.com/features/irdisp2.htm
//
#define PRONTO_ONCE        false
#define PRONTO_REPEAT      true
#define PRONTO_FALLBACK    true
#define PRONTO_NOFALLBACK  false

//------------------------------------------------------------------------------
// An enumerated list of all supported formats
// You do NOT need to remove entries from this list when disabling protocols!
//
typedef
	enum {
		UNUSEDstd      = -1,
		UNKNOWNstd       =  0,
		RC5std,
		RC6std,
		NECstd,
		SONYstd,
		PANASONICstd,
		JVCstd,
		SAMSUNGstd,
		WHYNTERstd,
		AIWA_RC_T501std,
		LGstd,
		SANYOstd,
		MITSUBISHIstd,
		DISHstd,
		SHARPstd,
		DENONstd,
		PRONTOstd,
	}
decode_type_tstd;

//------------------------------------------------------------------------------
// Set DEBUG to 1 for lots of lovely debug output
//
#define DEBUG  0

//------------------------------------------------------------------------------
// Debug directives
//
#if DEBUG
#	define DBG_PRINT(...)    Serial.print(__VA_ARGS__)
#	define DBG_PRINTLN(...)  Serial.println(__VA_ARGS__)
#else
#	define DBG_PRINT(...)
#	define DBG_PRINTLN(...)
#endif

//------------------------------------------------------------------------------
// Mark & Space matching functions
//
int  MATCHstd       (int measured, int desired) ;
int  MATCH_MARKstd  (int measured_ticks, int desired_us) ;
int  MATCH_SPACEstd (int measured_ticks, int desired_us) ;

//------------------------------------------------------------------------------
// Results returned from the decoder
//
class decode_resultsstd
{
	public:
		decode_type_tstd          decode_typestd;  // UNKNOWN, NEC, SONY, RC5, ...
		unsigned int           addressstd;      // Used by Panasonic & Sharp [16-bits]
		unsigned long          valuestd;        // Decoded value [max 32-bits]
		int                    bitsstd;         // Number of bits in decoded value
		volatile unsigned int  *rawbufstd;      // Raw intervals in 50uS ticks
		int                    rawlenstd;       // Number of records in rawbuf
		int                    overflowstd;     // true iff IR raw code too long
};

//------------------------------------------------------------------------------
// Decoded value for NEC when a repeat code is received
//
#define REPEATstd 0xFFFFFFFF

//------------------------------------------------------------------------------
// Main class for receiving IR
//
class IRrecvstd
{
	public:
		IRrecvstd (int recvpin) ;
		IRrecvstd (int recvpin, int blinkpin);

		void  blink12    (int blinkflag) ;
		int   decodestd     (decode_resultsstd *resultstd) ;
		void  enableIRInstd ( ) ;
		bool  isIdle     ( ) ;
		void  resumestd     ( ) ;

	private:
		long  decodeHashstd (decode_resultsstd *resultstd) ;
		int   compare    (unsigned int oldval, unsigned int newval) ;

		//......................................................................
#		if (DECODE_RC5 || DECODE_RC6)
			// This helper function is shared by RC5 and RC6
			int  getRClevel (decode_resultsstd *resultstd,  int *offset,  int *used,  int t1) ;
#		endif
#		if DECODE_RC5
			bool  decodeRC5std        (decode_resultsstd *resultstd) ;
#		endif
#		if DECODE_RC6
			bool  decodeRC6std        (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_NEC
			bool  decodeNECstd        (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_SONY
			bool  decodeSonystd       (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_PANASONIC
			bool  decodePanasonicstd  (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_JVC
			bool  decodeJVCstd        (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_SAMSUNG
			bool  decodeSAMSUNGstd    (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_WHYNTER
			bool  decodeWhynterstd    (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_AIWA_RC_T501
			bool  decodeAiwaRCT501std (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_LG
			bool  decodeLGstd         (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_SANYO
			bool  decodeSanyostd      (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_MITSUBISHI
			bool  decodeMitsubishistd (decode_resultsstd *resultstd) ;
#		endif
		//......................................................................
#		if DECODE_DISH
			bool  decodeDishstd (decode_resultsstd *resultstd) ; // NOT WRITTEN
#		endif
		//......................................................................
#		if DECODE_SHARP
			bool  decodeSharpstd (decode_resultsstd *resultstd) ; // NOT WRITTEN
#		endif
		//......................................................................
#		if DECODE_DENON
			bool  decodeDenonstd (decode_resultsstd *resultstd) ;
#		endif
} ;

//------------------------------------------------------------------------------
// Main class for sending IR
//
class IRsendstd
{
	public:
		IRsendstd () { }

		void  custom_delay_usec (unsigned long uSecs);
		void  enableIROutstd 		(int khz) ;
		void  mark        		(unsigned int usec) ;
		void  space       		(unsigned int usec) ;
		void  sendRawstd     		(unsigned int buf[],  unsigned int len,  unsigned int hz) ;

		//......................................................................
#		if SEND_RC5
			void  sendRC5std        (unsigned long data,  int nbits) ;
#		endif
#		if SEND_RC6
			void  sendRC6std        (unsigned long data,  int nbits) ;
#		endif
		//......................................................................
#		if SEND_NEC
			void  sendNECstd        (unsigned long data,  int nbits) ;
#		endif
		//......................................................................
#		if SEND_SONY
			void  sendSonystd       (unsigned long data,  int nbits) ;
#		endif
		//......................................................................
#		if SEND_PANASONIC
			void  sendPanasonicstd  (unsigned int addressstd,  unsigned long data) ;
#		endif
		//......................................................................
#		if SEND_JVC
			// JVC does NOT repeat by sending a separate code (like NEC does).
			// The JVC protocol repeats by skipping the header.
			// To send a JVC repeat signal, send the original code value
			//   and set 'repeat' to true
			void  sendJVCstd        (unsigned long data,  int nbits,  bool repeat) ;
#		endif
		//......................................................................
#		if SEND_SAMSUNG
			void  sendSAMSUNGstd    (unsigned long data,  int nbits) ;
#		endif
		//......................................................................
#		if SEND_WHYNTER
			void  sendWhynterstd    (unsigned long data,  int nbits) ;
#		endif
		//......................................................................
#		if SEND_AIWA_RC_T501
			void  sendAiwaRCT501std (int code) ;
#		endif
		//......................................................................
#		if SEND_LG
			void  sendLGstd         (unsigned long data,  int nbits) ;
#		endif
		//......................................................................
#		if SEND_SANYO
			void  sendSanyostd      ( ) ; // NOT WRITTEN
#		endif
		//......................................................................
#		if SEND_MISUBISHI
			void  sendMitsubishistd ( ) ; // NOT WRITTEN
#		endif
		//......................................................................
#		if SEND_DISH
			void  sendDISHstd       (unsigned long data,  int nbits) ;
#		endif
		//......................................................................
#		if SEND_SHARP
			void  sendSharpRawstd   (unsigned long data,  int nbits) ;
			void  sendSharpstd      (unsigned int addressstd,  unsigned int command) ;
#		endif
		//......................................................................
#		if SEND_DENON
			void  sendDenonstd      (unsigned long data,  int nbits) ;
#		endif
		//......................................................................
#		if SEND_PRONTO
			void  sendProntostd     (char* code,  bool repeat,  bool fallback) ;
#		endif
} ;

#endif
